<?php 

	include '../koneksi.php';

	$telepon = $_POST['telepon'];
	$sandi = $_POST['sandi'];

	$sql = "SELECT * FROM user WHERE telepon = '$telepon' && sandi = '$sandi'";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

	if (mysqli_num_rows($query) > 0) {
		$row = mysqli_fetch_array($query);
		array_push($result, array(
			"id" 		=> $row['id'],
			"nama" 		=> $row['nama'],
			"email" 	=> $row['email'],
			"telepon"	=> $row['telepon'],
			"sandi" 	=> $row['sandi'],
			"level" 	=> $row['level']
		));

		echo json_encode(array('result'=>$result));
	} else {
		echo json_encode(array('result'=>"gagal login")); 
	}

	mysqli_close($konekkan);

 ?>