<?php 
    
    include '../koneksi.php';

    $id     = $_POST['id'];

    $sql = "UPDATE user SET sandi = '123' WHERE id = '$id'";

    if(mysqli_query($konekkan, $sql)){
        echo 'Alhamdulillah sandi berhasil direset';
    }else{
        echo 'Astaghfirullah gagal mereset sandi';
    }
    
    mysqli_close($konekkan);

 ?>