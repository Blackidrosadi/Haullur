<?php
	
	include '../koneksi.php';

	$sql = "SELECT * FROM user ORDER BY nama ASC";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

	while ($row = mysqli_fetch_array($query)) {
		array_push($result, array(
			"id" 		=> $row['id'],
			"nama" 		=> $row['nama'],
			"email" 	=> $row['email'],
			"telepon"	=> $row['telepon'],
			"sandi"		=> $row['sandi'],
			"level"		=> $row['level']
		));
	}

	echo json_encode(array('result' => $result));
	mysqli_close($konekkan);
?>