<?php 
    
    include '../koneksi.php';

    $id     = $_POST['id'];

    $sql = "DELETE FROM user WHERE id = '$id'";

    if(mysqli_query($konekkan, $sql)){
        echo 'Alhamdulillah akun berhasil dihapus';
    }else{
        echo 'Astaghfirullah gagal menghapus akun';
    }
    
    mysqli_close($konekkan);

 ?>