<?php 
    
    include '../koneksi.php';

    $id     = $_POST['id'];

    $sql = "UPDATE keluarga SET id_user = 0 WHERE id = '$id'";

    if(mysqli_query($konekkan, $sql)){
        echo 'Alhamdulillah penugasan berhasil diperbarui';
    }else{
        echo 'Astaghfirullah penugasan gagal diperbarui';
    }
    
    mysqli_close($konekkan);

 ?>