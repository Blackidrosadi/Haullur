<?php 

	include '../koneksi.php';
	
	$id = $_GET['id'];

	$sql = "SELECT COUNT(id) as jumlah, SUM(jumlah) as total FROM penarikan WHERE id_user = '$id'";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

	$row = mysqli_fetch_array($query);
	array_push($result, array(
		"jumlah" 	=> $row['jumlah'],
		"total"     => $row['total']
	));

	echo json_encode(array('result'=>$result));
	mysqli_close($konekkan);

 ?>