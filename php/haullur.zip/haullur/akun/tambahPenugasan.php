<?php 

	include '../koneksi.php';

	$id_keluarga = $_POST['id_keluarga'];
	$id_user = $_POST['id_akun'];

	$sql = "UPDATE keluarga SET id_user = '$id_user' WHERE id = '$id_keluarga'";

	if(mysqli_query($konekkan, $sql)){
		echo 'Alhamdulillah penugasan berhasil diperbarui';
	}else{
		echo 'Astaghfirullah penugasan gagal diperbarui';
	}
	
	mysqli_close($konekkan);

 ?>