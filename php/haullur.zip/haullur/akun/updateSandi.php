<?php 
    
    include '../koneksi.php';

    $id     = $_POST['id'];
    $sandi  = $_POST['sandi'];

    $sql = "UPDATE user SET sandi = '$sandi' WHERE id = '$id'";

    if(mysqli_query($konekkan, $sql)){
        echo 'Alhamdulillah sandi berhasil diperbarui';
    }else{
        echo 'Astaghfirullah gagal memperbarui sandi';
    }
    
    mysqli_close($konekkan);

 ?>