<?php 

	include '../koneksi.php';

	$telepon = $_GET['telepon'];

	$sql = "SELECT count(id) FROM user WHERE telepon = '$telepon'";
	$query = mysqli_query($konekkan, $sql);
	$row = mysqli_fetch_array($query);

	if ($row[0] > 0) {
		echo '1';
	} else {
		echo '0';
	}

	mysqli_close($konekkan);

 ?>