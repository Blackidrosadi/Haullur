<?php 
    
    include '../koneksi.php';

    $id     = $_POST['id'];
    $level  = $_POST['level'];

    $sql = "UPDATE user SET level = '$level' WHERE id = '$id'";

    if(mysqli_query($konekkan, $sql)){
        echo 'Alhamdulillah akun berhasil diperbarui';
    }else{
        echo 'Astaghfirullah akun gagal diperbarui';
    }
    
    mysqli_close($konekkan);

 ?>