<?php 

	include '../koneksi.php';

	$nama = $_POST['nama'];
	$email = $_POST['email'];
	$telepon = $_POST['telepon'];
	$sandi = $_POST['sandi'];
	$level = $_POST['level'];

	$sql = "INSERT INTO user (nama, email, telepon, sandi, level) VALUES ('$nama', '$email', '$telepon', '$sandi', '$level')";

	if (mysqli_query($konekkan, $sql)){
		echo 'Alhamdulillah berhasil mendaftarkan akun';
	} else {
		echo 'Astaghfirullah gagal mendaftarkan akun';
	}

	mysqli_close($konekkan);

 ?>