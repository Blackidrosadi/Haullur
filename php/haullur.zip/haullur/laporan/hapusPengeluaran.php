<?php 
    
    include '../koneksi.php';

    $id     = $_POST['id'];

    $sql = "DELETE FROM pengeluaran WHERE id = '$id'";

    if(mysqli_query($konekkan, $sql)){
        echo 'Alhamdulillah dana pengeluaran berhasil dihapus';
    }else{
        echo 'Astaghfirullah dana pengeluaran gagal dihapus';
    }
    
    mysqli_close($konekkan);

 ?>