<?php
	
	include '../koneksi.php';

    $id_haul = $_GET['id_haul'];

	$sql = "SELECT SUM(jumlah) as total_dana FROM penarikan WHERE id_haul = '$id_haul'";
	$res = mysqli_query($konekkan, $sql);
	$totaldanaNya = mysqli_fetch_assoc($res);

	$sqlpengeluaran = "SELECT SUM(jumlah) as pengeluaran FROM pengeluaran WHERE id_haul = '$id_haul'";
	$respengeluaran = mysqli_query($konekkan, $sqlpengeluaran);
	$pengeluaranNya = mysqli_fetch_assoc($respengeluaran);

	$totalKeseluruhan = $totaldanaNya['total_dana'] - $pengeluaranNya['pengeluaran'];

	echo json_encode(array('total_dana' => $totalKeseluruhan));
	mysqli_close($konekkan);
?>