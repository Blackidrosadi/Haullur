<?php 

	include '../koneksi.php';

	$id_haul 		= $_POST['id_haul'];
	$id_keluarga 	= $_POST['id_keluarga'];
	$jumlah_uang 	= $_POST['jumlah_uang'];
	$deskripsi 		= $_POST['deskripsi'];
	$id_akun 		= $_POST['id_akun'];

	$sql = "INSERT INTO penarikan (id_haul, id_keluarga, jumlah, deskripsi, id_user) 
	VALUES ('$id_haul', '$id_keluarga', '$jumlah_uang', '$deskripsi', '$id_akun')";

	if (mysqli_query($konekkan, $sql)){
		echo 'Alhamdulillah penambahan dana berhasil';
	} else {
		echo 'Astaghfirullah penambahan dana gagal';
	}

	mysqli_close($konekkan);

 ?>