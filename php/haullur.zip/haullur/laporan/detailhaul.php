<?php
	
	include '../koneksi.php';

    $id_haul = $_GET['id_haul'];

	$sql = "SELECT id_user, SUM(jumlah) as subtotal 
    FROM `penarikan` WHERE id_haul = '$id_haul' AND id_user != 0 
	GROUP BY id_user ORDER BY id DESC";

	$query = mysqli_query($konekkan, $sql);
	$result = array();

	while ($row = mysqli_fetch_array($query)) {
        $sqluser = "SELECT nama FROM user WHERE id = " . $row['id_user'];
		$resuser = mysqli_query($konekkan, $sqluser);
		$userNya = mysqli_fetch_assoc($resuser);

		array_push($result, array(
			"id_akun" 		=> $row['id_user'],
			"nama" 		    => $userNya['nama'],
			"subtotal" 	    => $row['subtotal']
		));
	}

	echo json_encode(array('result' => $result));
	mysqli_close($konekkan);
?>