<?php 

	include '../koneksi.php';

	$id_haul 		= $_POST['id_haul'];
	$deskripsi 		= $_POST['deskripsi'];
	$jumlah_uang 	= $_POST['jumlah_uang'];

	$sql = "INSERT INTO pengeluaran (id_haul, deskripsi, jumlah) 
	VALUES ('$id_haul', '$deskripsi', '$jumlah_uang')";

	if (mysqli_query($konekkan, $sql)){
		echo 'Alhamdulillah transaksi pengeluaran dana berhasil';
	} else {
		echo 'Astaghfirullah transaksi pengeluaran dana gagal';
	}

	mysqli_close($konekkan);

 ?>