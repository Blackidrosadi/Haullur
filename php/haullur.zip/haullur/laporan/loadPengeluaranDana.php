<?php
	
	include '../koneksi.php';

	$id_haul = $_GET['id_haul'];

	$sql = "SELECT * FROM pengeluaran WHERE id_haul = '$id_haul' ORDER BY id DESC";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

	while ($row = mysqli_fetch_array($query)) {
		array_push($result, array(
            "id" 				=> $row['id'],
            "id_haul" 			=> $row['id_haul'],
            "deskripsi"			=> $row['deskripsi'],
            "jumlah_uang"		=> $row['jumlah']
        ));
	}

	echo json_encode(array('result' => $result));
	mysqli_close($konekkan);
?>