<?php
	
	include '../koneksi.php';

	$id_haul = $_GET['id_haul'];

	$sql = "SELECT * FROM penarikan WHERE id_haul = '$id_haul' AND id_user = 0 ORDER BY id DESC";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

	while ($row = mysqli_fetch_array($query)) {
		$sqlid = "SELECT COUNT(id) as jumlah_almarhum FROM almarhums WHERE id_keluarga = " . $row['id_keluarga'];
		$resid = mysqli_query($konekkan, $sqlid);
		$valueid = mysqli_fetch_assoc($resid);

        if ($row['id_keluarga'] == 0) {
            array_push($result, array(
                "id" 				=> $row['id'],
                "id_haul" 			=> $row['id_haul'],
                "id_keluarga" 		=> $row['id_keluarga'],
                "jumlah_uang"		=> $row['jumlah'],
                "deskripsi"			=> $row['deskripsi'],
                "id_akun"			=> $row['id_user'],
                "nama"				=> "",
                "rt"				=> "",
                "jumlah_almarhum"	=> $valueid['jumlah_almarhum']
            ));
        } else {
            $sqlkeluarga = "SELECT nama, rt FROM keluarga WHERE id = " . $row['id_keluarga'];
            $reskeluarga = mysqli_query($konekkan, $sqlkeluarga);
            $valuekeluarga = mysqli_fetch_assoc($reskeluarga);

            array_push($result, array(
                "id" 				=> $row['id'],
                "id_haul" 			=> $row['id_haul'],
                "id_keluarga" 		=> $row['id_keluarga'],
                "jumlah_uang"		=> $row['jumlah'],
                "deskripsi"			=> $row['deskripsi'],
                "id_akun"			=> $row['id_user'],
                "nama"				=> $valuekeluarga['nama'],
                "rt"				=> $valuekeluarga['rt'],
                "jumlah_almarhum"	=> $valueid['jumlah_almarhum']
            ));
        }
	}

	echo json_encode(array('result' => $result));
	mysqli_close($konekkan);
?>