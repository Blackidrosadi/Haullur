<?php 
    
    include '../koneksi.php';

    $id     = $_POST['id'];

    $sql = "DELETE FROM penarikan WHERE id = '$id'";

    if(mysqli_query($konekkan, $sql)){
        echo 'Alhamdulillah dana pemasukkan berhasil dihapus';
    }else{
        echo 'Astaghfirullah dana pemasukkan gagal dihapus';
    }
    
    mysqli_close($konekkan);

 ?>