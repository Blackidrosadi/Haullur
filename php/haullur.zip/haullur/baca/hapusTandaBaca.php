<?php 

	include '../koneksi.php';

	$id = $_POST['id'];

	$sql = "UPDATE penarikan SET dibaca = 0 WHERE id = '$id'";

	if(mysqli_query($konekkan, $sql)){
		echo 'Tanda telah dibaca dihapus.';
	}else{
		echo 'Astaghfirullah gagal menghapus tanda telah dibaca.';
	}
	
	mysqli_close($konekkan);

 ?>