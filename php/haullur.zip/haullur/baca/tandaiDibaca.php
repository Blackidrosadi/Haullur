<?php 

	include '../koneksi.php';

	$id = $_POST['id'];

	$sql = "UPDATE penarikan SET dibaca = 1 WHERE id = '$id'";

	if(mysqli_query($konekkan, $sql)){
		echo 'Alhamdulillah keluarga telah ditandai telah dibaca';
	}else{
		echo 'Astaghfirullah keluarga gagal ditandai telah dibaca';
	}
	
	mysqli_close($konekkan);

 ?>