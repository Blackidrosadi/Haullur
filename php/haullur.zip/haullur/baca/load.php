<?php

include '../koneksi.php';

$id_haul = $_GET['id_haul'];

$sql = "SELECT p.id, p.id_keluarga, k.nama, k.rt, p.dibaca 
	FROM penarikan p INNER JOIN keluarga k ON k.id = p.id_keluarga 
	WHERE p.id_haul = '$id_haul' ORDER BY p.id ASC";
$query = mysqli_query($konekkan, $sql);
$result = array();

while ($row = mysqli_fetch_array($query)) {
    $sqlid = "SELECT COUNT(id) as jumlah_almarhum FROM almarhums WHERE id_keluarga = " . $row['id_keluarga'];
    $resid = mysqli_query($konekkan, $sqlid);
    $valueid = mysqli_fetch_assoc($resid);

    $sqlkeluarga = "SELECT nama FROM almarhums WHERE id_keluarga = " . $row['id_keluarga'] . " ORDER BY id ASC";
    $querykeluarga = mysqli_query($konekkan, $sqlkeluarga);
    $resultkeluarga = array();

    while ($rowkeluarga = mysqli_fetch_array($querykeluarga)) {
        array_push($resultkeluarga, $rowkeluarga['nama']);
    }

    array_push($result, array(
        "id"                => $row['id'],
        "id_keluarga"       => $row['id_keluarga'],
        "nama"              => $row['nama'],
        "rt"                => $row['rt'],
        "jumlah_almarhum"   => $valueid['jumlah_almarhum'],
        "dibaca"            => $row['dibaca'],
        "almarhums"         => $resultkeluarga
    ));
}

echo json_encode(array('result' => $result));
mysqli_close($konekkan);
