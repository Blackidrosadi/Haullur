<?php 

	include '../koneksi.php';

    $id_haul = $_GET['id_haul'];

	$sqltotal = "SELECT COUNT(id) as total FROM penarikan WHERE id_haul = '$id_haul' AND id_keluarga != 0";
	$querytotal = mysqli_query($konekkan, $sqltotal);
	$restotal = array();

    $sqlsudah = "SELECT COUNT(id) as total FROM penarikan WHERE id_haul = '$id_haul' AND id_keluarga != 0 AND dibaca = 1";
	$ressudah = mysqli_query($konekkan, $sqlsudah);
	$valuesudah = mysqli_fetch_assoc($ressudah);

    $sqlbelum = "SELECT COUNT(id) as total FROM penarikan WHERE id_haul = '$id_haul' AND id_keluarga != 0 AND dibaca = 0";
	$resbelum = mysqli_query($konekkan, $sqlbelum);
	$valuebelum = mysqli_fetch_assoc($resbelum);

	$row = mysqli_fetch_array($querytotal);
	array_push($restotal, array(
		"total" 		=> $row['total'],
        "sudah_dibaca"  => $valuesudah['total'],
        "belum_dibaca"  => $valuebelum['total']
	));

	echo json_encode(array('result'=>$restotal));
	mysqli_close($konekkan);

 ?>