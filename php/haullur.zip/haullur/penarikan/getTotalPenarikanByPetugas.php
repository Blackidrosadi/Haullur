<?php
	
	include '../koneksi.php';

	$id_akun = $_POST['id'];
	$id_haul = $_POST['id_haul'];

	$sql = "SELECT SUM(jumlah) as total_uang FROM penarikan WHERE id_user = '$id_akun' AND id_haul = '$id_haul'";
	$query = mysqli_query($konekkan, $sql);
    $jumlahnya = mysqli_fetch_assoc($query);

	echo json_encode(array('result' => $jumlahnya['total_uang']));
	mysqli_close($konekkan);
?>