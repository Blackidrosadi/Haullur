<?php
	
	include '../koneksi.php';

	$id_akun = $_POST['id'];
	$id_haul = $_POST['id_haul'];

	$sql = "SELECT p.id, p.id_haul, p.id_keluarga, p.jumlah as jumlah_uang, p.deskripsi, p.id_user, k.nama, k.rt 
	FROM penarikan p INNER JOIN keluarga k ON k.id = p.id_keluarga 
	WHERE p.id_user = '$id_akun' AND p.id_haul = '$id_haul' ORDER BY p.id ASC";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

	while ($row = mysqli_fetch_array($query)) {
		$sqlid = "SELECT COUNT(id) as jumlah_almarhum FROM almarhums WHERE id_keluarga = " . $row['id_keluarga'];
		$resid = mysqli_query($konekkan, $sqlid);
		$valueid = mysqli_fetch_assoc($resid);
		array_push($result, array(
			"id" 				=> $row['id'],
			"id_haul" 			=> $row['id_haul'],
			"id_keluarga" 		=> $row['id_keluarga'],
			"jumlah_uang"		=> $row['jumlah_uang'],
			"deskripsi"			=> $row['deskripsi'],
			"id_akun"			=> $row['id_user'],
			"nama"				=> $row['nama'],
			"rt"				=> $row['rt'],
			"jumlah_almarhum"	=> $valueid['jumlah_almarhum']
		));
	}

	echo json_encode(array('result' => $result));
	mysqli_close($konekkan);
?>