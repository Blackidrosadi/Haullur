<?php 
    
    include '../koneksi.php';

    $id     = $_POST['id'];

    $sql = "DELETE FROM penarikan WHERE id = '$id'";

    if(mysqli_query($konekkan, $sql)){
        echo 'Alhamdulillah data penarikan berhasil dihapus';
    }else{
        echo 'Astaghfirullah data penarikan gagal dihapus';
    }
    
    mysqli_close($konekkan);

 ?>