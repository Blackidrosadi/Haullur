<?php 

	include '../koneksi.php';

	$id 	= $_POST['id'];
	$jumlah = $_POST['jumlah_uang'];

	$sql = "UPDATE penarikan SET jumlah = '$jumlah' WHERE id = '$id'";

	if(mysqli_query($konekkan, $sql)){
		echo 'Alhamdulillah dana penarikan berhasil diperbarui';
	}else{
		echo 'Astaghfirullah dana penarikan gagal diperbarui';
	}
	
	mysqli_close($konekkan);

 ?>