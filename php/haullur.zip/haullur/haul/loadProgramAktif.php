<?php 

	include '../koneksi.php';

	$sql = "SELECT * FROM haul WHERE status = 1";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

	$row = mysqli_fetch_array($query);
	array_push($result, array(
		"id" 		=> $row['id'],
		"tanggal" 	=> $row['tanggal'],
		"deskripsi" => $row['deskripsi'],
		"status"	=> $row['status']
	));

	echo json_encode(array('result'=>$result));
	mysqli_close($konekkan);

 ?>