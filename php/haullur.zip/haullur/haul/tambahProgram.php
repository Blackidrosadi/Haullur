<?php 

	include '../koneksi.php';

	$tanggal = $_POST['tanggal'];
	$deskripsi = $_POST['deskripsi'];

	$sql = "INSERT INTO haul (tanggal, deskripsi, status) VALUES ('$tanggal','$deskripsi', 1)";

	if (mysqli_query($konekkan, $sql)){
		echo 'Alhamdulillah berhasil menambahkan program haul';
	} else {
		echo 'Astaghfirullah gagal menambahkan program haul';
	}

	mysqli_close($konekkan);

 ?>