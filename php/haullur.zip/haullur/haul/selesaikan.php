<?php 
    
    include '../koneksi.php';

    $id     = $_POST['id'];

    $sql = "UPDATE haul SET status = '0' WHERE id = '$id'";

    if(mysqli_query($konekkan, $sql)){
        echo 'Alhamdulillah program haul berhasil diselesaikan';
    }else{
        echo 'Astaghfirullah gagal menyelesaikan program haul';
    }
    
    mysqli_close($konekkan);

 ?>