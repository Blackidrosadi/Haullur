<?php 

	include '../koneksi.php';

	$sql = "SELECT count(id) FROM haul WHERE status = 1";
	$query = mysqli_query($konekkan, $sql);
	$row = mysqli_fetch_array($query);

	if ($row[0] > 0) {
		echo '1';
	} else {
		echo '0';
	}

	mysqli_close($konekkan);

 ?>