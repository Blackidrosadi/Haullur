<?php
	
	include '../koneksi.php';

	$sql = "SELECT * FROM haul ORDER BY id DESC";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

	while ($row = mysqli_fetch_array($query)) {
        $sqltotal = "SELECT SUM(jumlah) as total_haul FROM penarikan WHERE id_haul = " . $row['id'];
		$restotal = mysqli_query($konekkan, $sqltotal);
		$totalNya = mysqli_fetch_assoc($restotal);

		$sqlpengeluaran = "SELECT SUM(jumlah) as pengeluaran FROM pengeluaran WHERE id_haul = " . $row['id'];
		$respengeluaran = mysqli_query($konekkan, $sqlpengeluaran);
		$pengeluaranNya = mysqli_fetch_assoc($respengeluaran);

		$totalKeseluruhan = $totalNya['total_haul'] - $pengeluaranNya['pengeluaran'];

		array_push($result, array(
			"id" 			=> $row['id'],
			"tanggal" 		=> $row['tanggal'],
			"deskripsi" 	=> $row['deskripsi'],
			"status"		=> $row['status'],
			"total"			=> $totalKeseluruhan
		));
	}

	echo json_encode(array('result' => $result));
	mysqli_close($konekkan);
?>