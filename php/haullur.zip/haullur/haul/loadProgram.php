<?php
	
	include '../koneksi.php';

	$sql = "SELECT * FROM haul ORDER BY id DESC";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

	while ($row = mysqli_fetch_array($query)) {
		array_push($result, array(
			"id" 			=> $row['id'],
			"tanggal" 		=> $row['tanggal'],
			"deskripsi" 	=> $row['deskripsi'],
			"status"		=> $row['status']
		));
	}

	echo json_encode(array('result' => $result));
	mysqli_close($konekkan);
?>