<?php
	
	include '../koneksi.php';
	
	$id_haul = $_GET['id_haul'];
	
	$sqlKeluarga = "SELECT COUNT(id) as jumlah_keluarga FROM penarikan WHERE id_haul = '$id_haul'";
	$resKeluarga = mysqli_query($konekkan, $sqlKeluarga);
	$valueKeluarga = mysqli_fetch_assoc($resKeluarga);

	$sql = "SELECT * FROM penarikan WHERE id_haul = '$id_haul'";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

    $total_almarhums = 0;
    	
	while ($row = mysqli_fetch_array($query)) {
	    $sqlAlmarhum = "SELECT COUNT(id) as jumlah_almarhum FROM almarhums WHERE id_keluarga = " . $row['id_keluarga'];
	    $resAlmarhum = mysqli_query($konekkan, $sqlAlmarhum);
    	$valueAlmarhum = mysqli_fetch_assoc($resAlmarhum);
	    
	    $total_almarhums += $valueAlmarhum['jumlah_almarhum'];
	}
	
	array_push($result, array(
	    "jumlah_keluarga"   => $valueKeluarga['jumlah_keluarga'],
	    "jumlah_almarhums"  => $total_almarhums
    ));

	echo json_encode(array('result' => $result));
	mysqli_close($konekkan);
?>