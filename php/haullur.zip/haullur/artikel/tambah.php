<?php 

	include '../koneksi.php';

	$foto_tamnel = $_POST['foto_tamnel'];
	$judul = $_POST['judul'];
	$lokasi = $_POST['lokasi'];
	$tanggal = $_POST['tanggal'];
	$deskripsi = $_POST['deskripsi'];
	
	$namaFoto = date("dmY-His") . ".png";
	$lokasiFoto = $_SERVER['DOCUMENT_ROOT'] . "/haullur/images/thumbnail/";

	$sql = "INSERT INTO artikel (tamnel, judul, tanggal, lokasi, deskripsi, dilihat, id_haul) VALUES ('$namaFoto', '$judul', '$tanggal', '$lokasi', '$deskripsi', 87, 0)";

	if (mysqli_query($konekkan, $sql)){
	    $file = $lokasiFoto . $namaFoto;
	    file_put_contents($file, base64_decode($foto_tamnel));
		echo 'Alhamdulillah berhasil menambahkan artikel';
	} else {
		echo 'Astaghfirullah gagal menambahkan artikel';
	}

	mysqli_close($konekkan);

 ?>