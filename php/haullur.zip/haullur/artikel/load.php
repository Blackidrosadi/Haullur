<?php
	
	include '../koneksi.php';

	$sql = "SELECT * FROM artikel ORDER BY id DESC";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

	while ($row = mysqli_fetch_array($query)) {
		array_push($result, array(
			"id" 			=> $row['id'],
			"foto_tamnel"   => $row['tamnel'],
			"judul" 	    => $row['judul'],
			"tanggal"		=> $row['tanggal'],
			"lokasi"		=> $row['lokasi'],
			"deskripsi"		=> $row['deskripsi'],
			"dilihat"		=> $row['dilihat'],
			"id_haul"		=> $row['id_haul'],
			"foto"			=> $row['foto'],
			"foto2"			=> $row['foto2']
		));
	}

	echo json_encode(array('result' => $result));
	mysqli_close($konekkan);
?>