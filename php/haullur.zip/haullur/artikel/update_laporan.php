<?php 

	include '../koneksi.php';

	$id = $_POST['id'];
	$foto_tamnel = $_POST['foto_tamnel'];
	$judul = $_POST['judul'];
	$lokasi = $_POST['lokasi'];
	$deskripsi = $_POST['deskripsi'];
	$foto = $_POST['foto'];
	$foto2 = $_POST['foto2'];

	$old_foto_tamnel_name = $_POST['old_tamnel_name'];
	$old_foto_name = $_POST['old_foto_name'];
	$old_foto2_name = $_POST['old_foto2_name'];

	$namaFotoTamnel = date("dmY-His") . ".png";
	$lokasiFotoTamnel = $_SERVER['DOCUMENT_ROOT'] . "/haullur/images/thumbnail/";

	$namaFoto = date("dmY-His") . ".png";
	$namaFoto2 = date("dmY-His") . "_2.png";
	$lokasiFotoArtikel = $_SERVER['DOCUMENT_ROOT'] . "/haullur/images/artikel/";

	if ($foto_tamnel == 'tidak-berubah') {
		if ($foto != "" && $foto2 != "") {
			$sql = "UPDATE artikel SET judul = '$judul', lokasi = '$lokasi', deskripsi = '$deskripsi', foto = '$namaFoto', foto2 = '$namaFoto2' WHERE id = '$id'";
		} else if ($foto != "" && $foto2 == "") {
			$sql = "UPDATE artikel SET judul = '$judul', lokasi = '$lokasi', deskripsi = '$deskripsi', foto = '$namaFoto', foto2 = '' WHERE id = '$id'";
		} else if ($foto == "" && $foto2 == "") {
			$sql = "UPDATE artikel SET judul = '$judul', lokasi = '$lokasi', deskripsi = '$deskripsi', foto = '', foto2 = '' WHERE id = '$id'";
		}
	} else {
		if ($foto != "" && $foto2 != "") {
			$sql = "UPDATE artikel SET tamnel = '$namaFotoTamnel', judul = '$judul', lokasi = '$lokasi', deskripsi = '$deskripsi', foto = '$namaFoto', foto2 = '$namaFoto2' WHERE id = '$id'";
		} else if ($foto != "" && $foto2 == "") {
			$sql = "UPDATE artikel SET tamnel = '$namaFotoTamnel', judul = '$judul', lokasi = '$lokasi', deskripsi = '$deskripsi', foto = '$namaFoto', foto2 = '' WHERE id = '$id'";
		} else if ($foto == "" && $foto2 == "") {
			$sql = "UPDATE artikel SET tamnel = '$namaFotoTamnel', judul = '$judul', lokasi = '$lokasi', deskripsi = '$deskripsi', foto = '', foto2 = '' WHERE id = '$id'";
		}
	}

	if(mysqli_query($konekkan, $sql)) {
		if ($foto_tamnel != "tidak-berubah") {
			$file = $lokasiFotoTamnel . $namaFotoTamnel;
	    	file_put_contents($file, base64_decode($foto_tamnel));
			unlink($lokasiFotoTamnel . $old_foto_tamnel_name);
		}
		
		if ($foto != "") {
			$fileFoto = $lokasiFotoArtikel . $namaFoto;
			file_put_contents($fileFoto, base64_decode($foto));
			if ($old_foto_name != "") {
				unlink($lokasiFotoArtikel . $old_foto_name);
			}
		} else {
			if ($old_foto_name != "") {
				unlink($lokasiFotoArtikel . $old_foto_name);
			}
		}
		
		if ($foto2 != "") {
			$fileFoto2 = $lokasiFotoArtikel . $namaFoto2;
			file_put_contents($fileFoto2, base64_decode($foto2));
			if ($old_foto2_name != "") {
				unlink($lokasiFotoArtikel . $old_foto2_name);
			}
		} else {
			if ($old_foto2_name != "") {
				unlink($lokasiFotoArtikel . $old_foto2_name);
			}
		}

		echo 'Alhamdulillah berhasil memperbarui artikel';
	}else{
		echo 'Astaghfirullah artikel gagal diperbarui';
	}
	
	mysqli_close($konekkan);

 ?>