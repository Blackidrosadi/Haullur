<?php 

	include '../koneksi.php';

	$foto_tamnel = $_POST['foto_tamnel'];
	$judul = $_POST['judul'];
	$lokasi = $_POST['lokasi'];
	$tanggal = $_POST['tanggal'];
	$deskripsi = $_POST['deskripsi'];
	$id_haul = $_POST['id_haul'];
	$foto = $_POST['foto'];
	$foto2 = $_POST['foto2'];
	
	$namaFotoTamnel = date("dmY-His") . ".png";
	$lokasiFotoTamnel = $_SERVER['DOCUMENT_ROOT'] . "/haullur/images/thumbnail/";

	$namaFoto = date("dmY-His") . ".png";
	$namaFoto2 = date("dmY-His") . "_2.png";
	$lokasiFotoArtikel = $_SERVER['DOCUMENT_ROOT'] . "/haullur/images/artikel/";

	if ($foto != "" && $foto2 != "") {
		$sql = "INSERT INTO artikel (tamnel, judul, tanggal, lokasi, deskripsi, dilihat, id_haul, foto, foto2) VALUES ('$namaFotoTamnel', '$judul', '$tanggal', '$lokasi', '$deskripsi', 87, '$id_haul', '$namaFoto', '$namaFoto2')";
	} else if ($foto != "" && $foto2 == "") {
		$sql = "INSERT INTO artikel (tamnel, judul, tanggal, lokasi, deskripsi, dilihat, id_haul, foto, foto2) VALUES ('$namaFotoTamnel', '$judul', '$tanggal', '$lokasi', '$deskripsi', 87, '$id_haul', '$namaFoto', '')";
	} else if ($foto == "" && $foto2 == "") {
		$sql = "INSERT INTO artikel (tamnel, judul, tanggal, lokasi, deskripsi, dilihat, id_haul, foto, foto2) VALUES ('$namaFotoTamnel', '$judul', '$tanggal', '$lokasi', '$deskripsi', 87, '$id_haul', '', '')";
	}

	if (mysqli_query($konekkan, $sql)){
	    $file = $lokasiFotoTamnel . $namaFotoTamnel;
	    file_put_contents($file, base64_decode($foto_tamnel));
		
		if ($foto != "") {
			$fileFoto = $lokasiFotoArtikel . $namaFoto;
			file_put_contents($fileFoto, base64_decode($foto));
		}
		
		if ($foto2 != "") {
			$fileFoto2 = $lokasiFotoArtikel . $namaFoto2;
			file_put_contents($fileFoto2, base64_decode($foto2));
		}

		echo 'Alhamdulillah berhasil menambahkan artikel';
	} else {
		echo 'Astaghfirullah gagal menambahkan artikel';
	}

	mysqli_close($konekkan);

 ?>