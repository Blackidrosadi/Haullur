<?php 
    
    include '../koneksi.php';

    $id     = $_POST['id'];
	
	$old_foto_tamnel_name = $_POST['old_tamnel_name'];
	$old_foto_name = $_POST['old_foto_name'];
	$old_foto2_name = $_POST['old_foto2_name'];

    $sql = "DELETE FROM artikel WHERE id = '$id'";

    if(mysqli_query($konekkan, $sql)){
		unlink($_SERVER['DOCUMENT_ROOT'] . "/haullur/images/thumbnail/" . $old_foto_tamnel_name);

		if ($old_foto_name != "") {
			unlink($_SERVER['DOCUMENT_ROOT'] . "/haullur/images/artikel/" . $old_foto_name);
		}

		if ($old_foto2_name != "") {
			unlink($_SERVER['DOCUMENT_ROOT'] . "/haullur/images/artikel/" . $old_foto2_name);
		}

        echo 'Alhamdulillah, Artikel laporan berhasil dihapus';
    }else{
        echo 'Astaghfirullah gagal menghapus artikel laporan';
    }
    
    mysqli_close($konekkan);

 ?>