<?php
	
	include '../koneksi.php';

	$nama	= $_POST['nama'];
	$rt		= $_POST['rt'];

	$sql = "SELECT * FROM keluarga WHERE nama = '$nama' AND rt = '$rt'";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

	while ($row = mysqli_fetch_array($query)) {
		array_push($result, array(
			"id" 		=> $row['id'],
			"nama" 		=> $row['nama'],
			"rt" 		=> $row['rt'],
			"telepon"	=> $row['telepon'],
			"jumlah_almarhum"	=> "0"
		));
	}

	echo json_encode(array('result' => $result));
	mysqli_close($konekkan);
?>