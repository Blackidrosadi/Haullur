<?php
	
	include '../koneksi.php';

	$idKeluarga = $_GET['id'];

	$sql = "SELECT * FROM almarhums WHERE id_keluarga = '$idKeluarga' ORDER BY id ASC";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

	while ($row = mysqli_fetch_array($query)) {
		array_push($result, array(
			"id" 			=> $row['id'],
			"nama" 			=> $row['nama'],
			"id_keluarga"	=> $row['id_keluarga']
		));
	}

	echo json_encode(array('result' => $result));
	mysqli_close($konekkan);
?>