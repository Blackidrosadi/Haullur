<?php 
    
    include '../koneksi.php';

    $id     = $_POST['id'];

    $sql = "DELETE FROM almarhums WHERE id = '$id'";

    if(mysqli_query($konekkan, $sql)){
        echo 'Alhamdulillah data almarhum berhasil dihapus';
    }else{
        echo 'Astaghfirullah data almarhum gagal dihapus';
    }
    
    mysqli_close($konekkan);

 ?>