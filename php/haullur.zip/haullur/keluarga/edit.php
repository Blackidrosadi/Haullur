<?php 

	include '../koneksi.php';

	$id 	= $_POST['id'];
	$nama 	= $_POST['nama'];
	$rt 	= $_POST['rt'];
	$telepon = $_POST['telepon'];

	$sql = "UPDATE keluarga SET nama = '$nama', rt = '$rt', telepon = '$telepon' WHERE id = '$id'";

	if(mysqli_query($konekkan, $sql)){
		echo 'Alhamdulillah data keluarga berhasil diperbarui';
	}else{
		echo 'Astaghfirullah data keluarga gagal diperbarui';
	}
	
	mysqli_close($konekkan);

 ?>