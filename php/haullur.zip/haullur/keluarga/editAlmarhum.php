<?php 

	include '../koneksi.php';

	$id 	= $_POST['id'];
	$nama 	= $_POST['nama'];

	$sql = "UPDATE almarhums SET nama = '$nama' WHERE id = '$id'";

	if(mysqli_query($konekkan, $sql)){
		echo 'Alhamdulillah data almarhum berhasil diperbarui';
	}else{
		echo 'Astaghfirullah data almarhum gagal diperbarui';
	}
	
	mysqli_close($konekkan);

 ?>