<?php 

	include '../koneksi.php';

	$nama = $_POST['nama'];
	$rt = $_POST['rt'];
	$telepon = $_POST['telepon'];

	$sql = "INSERT INTO keluarga (nama, rt, telepon) VALUES ('$nama','$rt','$telepon')";

	if (mysqli_query($konekkan, $sql)){
		echo 'Alhamdulillah berhasil menambahkan keluarga';
	} else {
		echo 'Astaghfirullah gagal menambahkan keluarga';
	}

	mysqli_close($konekkan);

 ?>