<?php
	
	include '../koneksi.php';

	$cari = $_GET['cari'];

	$sql = "SELECT * FROM keluarga WHERE nama LIKE '%$cari%' ORDER BY nama ASC LIMIT 10";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

	while ($row = mysqli_fetch_array($query)) {
		$sqlid = "SELECT COUNT(id) as jumlah_almarhum FROM almarhums WHERE id_keluarga = " . $row['id'];
		$resid = mysqli_query($konekkan, $sqlid);
		$valueid = mysqli_fetch_assoc($resid);
		array_push($result, array(
			"id" 		=> $row['id'],
			"nama" 		=> $row['nama'],
			"rt" 		=> $row['rt'],
			"telepon"	=> $row['telepon'],
			"jumlah_almarhum"	=> $valueid['jumlah_almarhum']
		));
	}

	echo json_encode(array('result' => $result));
	mysqli_close($konekkan);
?>