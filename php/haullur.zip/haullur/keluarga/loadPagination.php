<?php
	
	$page = $_GET['page'];

	$start = 0;
	$limit = 10;

	include '../koneksi.php';

	$total = mysqli_num_rows(mysqli_query($konekkan, "SELECT id FROM keluarga"));
	$page_limit = $total/$limit;

	if ($page <= $page_limit + 1) {
		$start = ($page - 1) * $limit;

		$sql = "SELECT * FROM keluarga ORDER BY id DESC LIMIT $start, $limit";
		$query = mysqli_query($konekkan, $sql);
		$result = array();

		while ($row = mysqli_fetch_array($query)) {
			$sqlid = "SELECT COUNT(id) as jumlah_almarhum FROM almarhums WHERE id_keluarga = " . $row['id'];
			$resid = mysqli_query($konekkan, $sqlid);
			$valueid = mysqli_fetch_assoc($resid);
			array_push($result, array(
				"id" 		=> $row['id'],
				"nama" 		=> $row['nama'],
				"rt" 		=> $row['rt'],
				"telepon"	=> $row['telepon'],
				"jumlah_almarhum"	=> $valueid['jumlah_almarhum']
			));
		}

		echo json_encode($result);
	} else {
		echo "over";
	}

	mysqli_close($konekkan);
?>