<?php
	
	include '../koneksi.php';

	$idKeluarga = $_GET['id'];

	$sql = "SELECT count(id) FROM almarhums WHERE id_keluarga = '$idKeluarga'";
	$query = mysqli_query($konekkan, $sql);
	$row = mysqli_fetch_array($query);

	echo $row[0];

	mysqli_close($konekkan);
?>