<?php
	
	include '../koneksi.php';

	$sql = "SELECT * FROM keluarga ORDER BY id DESC";
	$query = mysqli_query($konekkan, $sql);
	$result = array();

	while ($row = mysqli_fetch_array($query)) {
		array_push($result, array(
			"id" 		=> $row['id'],
			"nama" 		=> $row['nama'],
			"rt" 		=> $row['rt'],
			"telepon"	=> $row['telepon']
		));
	}

	echo json_encode(array('result' => $result));
	mysqli_close($konekkan);
?>