<?php 

	include '../koneksi.php';

	$id_keluarga = $_POST['id'];
	$nama = $_POST['nama'];

	$sql = "INSERT INTO almarhums (nama, id_keluarga) VALUES ('$nama','$id_keluarga')";

	if (mysqli_query($konekkan, $sql)){
		echo 'Alhamdulillah berhasil menambahkan almarhum';
	} else {
		echo 'Astaghfirullah gagal menambahkan almarhum';
	}

	mysqli_close($konekkan);

 ?>