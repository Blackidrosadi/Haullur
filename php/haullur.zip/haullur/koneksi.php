<?php 
	
	// $host		= "localhost";
	// $username	= "rant8363";
	// $password	= "CaTXSKphZ34p57";
	// $database	= "rant8363_haullur";

	$host		= "localhost";
	$username	= "root";
	$password	= "";
	$database	= "haullur";

	$konekkan 	= mysqli_connect($host, $username, $password, $database);
 ?>